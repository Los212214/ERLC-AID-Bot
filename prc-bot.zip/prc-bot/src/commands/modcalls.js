'use strict';

const { SlashCommandBuilder } = require('discord.js');
const db = require('../database');
const { fetchServer, RateLimitError } = require('../api');
const embeds = require('../embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('modcalls')
    .setDescription('View recent moderator call logs.')
    .addIntegerOption(o => o.setName('limit').setDescription('Entries to show (max 25)').setMinValue(1).setMaxValue(25)),

  async execute(interaction) {
    await interaction.deferReply();
    const apiKey = db.getApiKey(interaction.guildId);
    if (!apiKey) return interaction.editReply({ embeds: [embeds.warn('Not Configured', 'Run `/setup` first.')] });

    const limit = interaction.options.getInteger('limit') ?? 15;

    try {
      const data = await fetchServer(apiKey, interaction.guildId, { ModCalls: true });
      const logs = (data.ModCalls ?? []).slice(0, limit);

      if (!logs.length) return interaction.editReply({ embeds: [embeds.info('No Mod Calls', 'No mod calls recorded yet.')] });

      const lines = logs.map(l => {
        const mod = l.Moderator ? `handled by **${l.Moderator}**` : '_unhandled_';
        return `📞 <t:${l.Timestamp}:t> — **${l.Caller}** called — ${mod}`;
      });

      return interaction.editReply({
        embeds: [embeds.base(0xFEE75C).setTitle(`📞  Mod Calls — ${data.Name}`).setDescription(lines.join('\n').slice(0, 4000))],
      });
    } catch (err) {
      if (err instanceof RateLimitError) return interaction.editReply({ embeds: [embeds.warn('Rate Limited', err.message)] });
      return interaction.editReply({ embeds: [embeds.error('API Error', err.message)] });
    }
  },
};
