'use strict';

const { SlashCommandBuilder } = require('discord.js');
const db = require('../database');
const { fetchServer, RateLimitError } = require('../api');
const embeds = require('../embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('vehicles')
    .setDescription('List all spawned vehicles in the private server.')
    .addStringOption(o => o.setName('filter').setDescription('Filter by vehicle name or owner (partial match)')),

  async execute(interaction) {
    await interaction.deferReply();
    const apiKey = db.getApiKey(interaction.guildId);
    if (!apiKey) return interaction.editReply({ embeds: [embeds.warn('Not Configured', 'Run `/setup` first.')] });

    const filter = interaction.options.getString('filter')?.toLowerCase();

    try {
      const data = await fetchServer(apiKey, interaction.guildId, { Vehicles: true });
      let vehicles = data.Vehicles ?? [];

      if (filter) {
        vehicles = vehicles.filter(v =>
          v.Name?.toLowerCase().includes(filter) ||
          v.Owner?.toLowerCase().includes(filter)
        );
      }

      if (!vehicles.length) return interaction.editReply({ embeds: [embeds.info('No Vehicles', 'No vehicles found.')] });

      const lines = vehicles.slice(0, 25).map(v => {
        const color = v.ColorName ? ` (${v.ColorName})` : '';
        const texture = v.Texture ? ` [${v.Texture}]` : '';
        return `🚗 **${v.Name}**${color}${texture}\n   👤 ${v.Owner} · 🪪 \`${v.Plate}\``;
      });

      const overflow = vehicles.length > 25 ? `\n_…and ${vehicles.length - 25} more_` : '';

      return interaction.editReply({
        embeds: [embeds.base()
          .setTitle(`🚗  Vehicles — ${data.Name}`)
          .setDescription(`**${vehicles.length}** vehicle(s) spawned\n\n${lines.join('\n\n')}${overflow}`.slice(0, 4000))],
      });
    } catch (err) {
      if (err instanceof RateLimitError) return interaction.editReply({ embeds: [embeds.warn('Rate Limited', err.message)] });
      return interaction.editReply({ embeds: [embeds.error('API Error', err.message)] });
    }
  },
};
