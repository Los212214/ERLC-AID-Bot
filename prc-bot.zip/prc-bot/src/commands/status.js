'use strict';

const { SlashCommandBuilder } = require('discord.js');
const db = require('../database');
const { fetchServer, RateLimitError } = require('../api');
const embeds = require('../embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('status')
    .setDescription('Show a full overview of the ER:LC private server.')
    .addBooleanOption(opt =>
      opt.setName('players').setDescription('Include player list (default: true)'))
    .addBooleanOption(opt =>
      opt.setName('queue').setDescription('Include queue info')),

  async execute(interaction) {
    await interaction.deferReply();

    const apiKey = db.getApiKey(interaction.guildId);
    if (!apiKey) return interaction.editReply({ embeds: [embeds.warn('Not Configured', 'Run `/setup` first to link your PRC server.')] });

    const includePlayers = interaction.options.getBoolean('players') ?? true;
    const includeQueue   = interaction.options.getBoolean('queue') ?? true;

    try {
      const data = await fetchServer(apiKey, interaction.guildId, {
        Players: includePlayers,
        Queue:   includeQueue,
      });

      return interaction.editReply({ embeds: [embeds.serverStatus(data)] });
    } catch (err) {
      if (err instanceof RateLimitError) return interaction.editReply({ embeds: [embeds.warn('Rate Limited', err.message)] });
      return interaction.editReply({ embeds: [embeds.error('API Error', err.message)] });
    }
  },
};
