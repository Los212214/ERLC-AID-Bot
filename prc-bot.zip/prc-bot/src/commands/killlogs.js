'use strict';

const { SlashCommandBuilder } = require('discord.js');
const db = require('../database');
const { fetchServer, RateLimitError } = require('../api');
const embeds = require('../embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('killlogs')
    .setDescription('View recent kill logs from the private server.')
    .addIntegerOption(opt =>
      opt.setName('limit').setDescription('Number of entries to show (max 25)').setMinValue(1).setMaxValue(25)),

  async execute(interaction) {
    await interaction.deferReply();

    const apiKey = db.getApiKey(interaction.guildId);
    if (!apiKey) return interaction.editReply({ embeds: [embeds.warn('Not Configured', 'Run `/setup` first.')] });

    const limit = interaction.options.getInteger('limit') ?? 15;

    try {
      const data = await fetchServer(apiKey, interaction.guildId, { KillLogs: true });
      const logs = (data.KillLogs ?? []).slice(0, limit);

      if (logs.length === 0) {
        return interaction.editReply({ embeds: [embeds.info('No Kill Logs', 'No kill logs recorded yet.')] });
      }

      const lines = logs.map(l => {
        const time = `<t:${l.Timestamp}:t>`;
        return `${time} — **${l.Killer}** killed **${l.Killed}**`;
      });

      return interaction.editReply({
        embeds: [embeds.base(0xED4245)
          .setTitle(`💀  Kill Logs — ${data.Name}`)
          .setDescription(lines.join('\n').slice(0, 4000))],
      });
    } catch (err) {
      if (err instanceof RateLimitError) return interaction.editReply({ embeds: [embeds.warn('Rate Limited', err.message)] });
      return interaction.editReply({ embeds: [embeds.error('API Error', err.message)] });
    }
  },
};
