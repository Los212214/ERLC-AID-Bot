'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../database');
const { fetchServer } = require('../api');
const embeds = require('../embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup')
    .setDescription('Configure your PRC ER:LC private server API key for this Discord server.')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption(opt =>
      opt.setName('api_key')
        .setDescription('Your PRC private server API key (found in Settings → API Key in-game)')
        .setRequired(true))
    .addStringOption(opt =>
      opt.setName('action')
        .setDescription('What to do with the config')
        .addChoices(
          { name: 'Set / Update key', value: 'set' },
          { name: 'Remove key',       value: 'remove' },
          { name: 'View current',     value: 'view' },
        )),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const action = interaction.options.getString('action') ?? 'set';
    const apiKey = interaction.options.getString('api_key');

    if (action === 'remove') {
      db.deleteConfig(interaction.guildId);
      return interaction.editReply({
        embeds: [embeds.success('Config Removed', 'Your PRC API key has been removed from this server.')],
      });
    }

    if (action === 'view') {
      const config = db.getConfig(interaction.guildId);
      if (!config) {
        return interaction.editReply({
          embeds: [embeds.warn('Not Configured', 'No API key is set for this server. Run `/setup` with your key to get started.')],
        });
      }
      const masked = config.api_key.slice(0, 6) + '•••••••••••' + config.api_key.slice(-4);
      return interaction.editReply({
        embeds: [embeds.info('Current Config', `**API Key:** \`${masked}\`\n**Set by:** <@${config.setup_by}>\n**Set at:** <t:${config.setup_at}:R>`)],
      });
    }

    // --- SET ---
    // Validate the key by making a quick test request
    try {
      await fetchServer(apiKey, null); // no guild rate-limit on setup
    } catch (err) {
      if (err.status === 403) {
        return interaction.editReply({
          embeds: [embeds.error('Invalid API Key', 'The key you provided was rejected by the PRC API. Make sure you copied it correctly from your in-game settings.')],
        });
      }
      // 422 = no players online — key is valid, server is just empty
      if (err.status !== 422) {
        return interaction.editReply({
          embeds: [embeds.error('Validation Failed', `Could not verify the key: ${err.message}`)],
        });
      }
    }

    db.setConfig(interaction.guildId, apiKey, interaction.user.id);

    return interaction.editReply({
      embeds: [embeds.success('Setup Complete!',
        'Your PRC API key has been saved.\n\n' +
        '**Available commands:**\n' +
        '`/status` · `/players` · `/staff` · `/killlogs` · `/commandlogs`\n' +
        '`/joinlogs` · `/vehicles` · `/modcalls` · `/emergencycalls` · `/queue`\n' +
        '`/run` · `/autostatus`')],
    });
  },
};
