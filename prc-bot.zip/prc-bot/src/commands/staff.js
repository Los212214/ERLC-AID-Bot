'use strict';

const { SlashCommandBuilder } = require('discord.js');
const db = require('../database');
const { fetchServer, RateLimitError } = require('../api');
const embeds = require('../embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('staff')
    .setDescription('Show online staff (Admins, Mods, Helpers) in the private server.'),

  async execute(interaction) {
    await interaction.deferReply();

    const apiKey = db.getApiKey(interaction.guildId);
    if (!apiKey) return interaction.editReply({ embeds: [embeds.warn('Not Configured', 'Run `/setup` first.')] });

    try {
      const data = await fetchServer(apiKey, interaction.guildId, { Staff: true });
      const staff = data.Staff ?? {};

      const admins  = Object.values(staff.Admins  ?? {});
      const mods    = Object.values(staff.Mods    ?? {});
      const helpers = Object.values(staff.Helpers ?? {});

      const total = admins.length + mods.length + helpers.length;

      if (total === 0) {
        return interaction.editReply({ embeds: [embeds.info('No Staff Online', 'No admins, mods, or helpers are currently in the server.')] });
      }

      const embed = embeds.base()
        .setTitle(`🛡️  Staff Online — ${data.Name}`)
        .setDescription(`**${total}** staff member(s) currently in-game`);

      if (admins.length)  embed.addFields({ name: `🔴 Admins (${admins.length})`,   value: admins.map(u => `• \`${u}\``).join('\n').slice(0, 1024),  inline: true });
      if (mods.length)    embed.addFields({ name: `🟡 Mods (${mods.length})`,       value: mods.map(u => `• \`${u}\``).join('\n').slice(0, 1024),    inline: true });
      if (helpers.length) embed.addFields({ name: `🟢 Helpers (${helpers.length})`, value: helpers.map(u => `• \`${u}\``).join('\n').slice(0, 1024), inline: true });

      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      if (err instanceof RateLimitError) return interaction.editReply({ embeds: [embeds.warn('Rate Limited', err.message)] });
      return interaction.editReply({ embeds: [embeds.error('API Error', err.message)] });
    }
  },
};
