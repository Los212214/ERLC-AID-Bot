'use strict';

const { SlashCommandBuilder } = require('discord.js');
const db = require('../database');
const { fetchServer, RateLimitError } = require('../api');
const embeds = require('../embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('joinlogs')
    .setDescription('View recent player join/leave events.')
    .addIntegerOption(o => o.setName('limit').setDescription('Entries to show (max 25)').setMinValue(1).setMaxValue(25))
    .addStringOption(o =>
      o.setName('type')
        .setDescription('Filter by join or leave')
        .addChoices(
          { name: 'All', value: 'all' },
          { name: 'Joins only', value: 'join' },
          { name: 'Leaves only', value: 'leave' },
        )),

  async execute(interaction) {
    await interaction.deferReply();
    const apiKey = db.getApiKey(interaction.guildId);
    if (!apiKey) return interaction.editReply({ embeds: [embeds.warn('Not Configured', 'Run `/setup` first.')] });

    const limit = interaction.options.getInteger('limit') ?? 15;
    const type  = interaction.options.getString('type') ?? 'all';

    try {
      const data = await fetchServer(apiKey, interaction.guildId, { JoinLogs: true });
      let logs = data.JoinLogs ?? [];

      if (type === 'join')  logs = logs.filter(l => l.Join === true);
      if (type === 'leave') logs = logs.filter(l => l.Join === false);

      logs = logs.slice(0, limit);

      if (!logs.length) return interaction.editReply({ embeds: [embeds.info('No Join Logs', 'No join/leave events found.')] });

      const lines = logs.map(l => {
        const icon = l.Join ? '🟢' : '🔴';
        const verb = l.Join ? 'joined' : 'left';
        return `${icon} <t:${l.Timestamp}:t> — **${l.Player}** ${verb}`;
      });

      return interaction.editReply({
        embeds: [embeds.base(0x57F287).setTitle(`📥  Join Logs — ${data.Name}`).setDescription(lines.join('\n').slice(0, 4000))],
      });
    } catch (err) {
      if (err instanceof RateLimitError) return interaction.editReply({ embeds: [embeds.warn('Rate Limited', err.message)] });
      return interaction.editReply({ embeds: [embeds.error('API Error', err.message)] });
    }
  },
};
