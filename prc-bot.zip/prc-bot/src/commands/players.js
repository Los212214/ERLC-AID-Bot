'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const db = require('../database');
const { fetchServer, RateLimitError } = require('../api');
const embeds = require('../embeds');

const TEAM_EMOJIS = {
  'Police':    '🚔',
  'Fire':      '🚒',
  'Sheriff':   '⭐',
  'DOT':       '🚧',
  'Civilian':  '👤',
  'Criminal':  '💀',
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('players')
    .setDescription('List all players currently in the private server.')
    .addStringOption(opt =>
      opt.setName('team')
        .setDescription('Filter by team')
        .addChoices(
          { name: 'All Teams',  value: 'all' },
          { name: 'Police',     value: 'Police' },
          { name: 'Fire',       value: 'Fire' },
          { name: 'Civilian',   value: 'Civilian' },
          { name: 'Criminal',   value: 'Criminal' },
        )),

  async execute(interaction) {
    await interaction.deferReply();

    const apiKey = db.getApiKey(interaction.guildId);
    if (!apiKey) return interaction.editReply({ embeds: [embeds.warn('Not Configured', 'Run `/setup` first.')] });

    const filterTeam = interaction.options.getString('team') ?? 'all';

    try {
      const data = await fetchServer(apiKey, interaction.guildId, { Players: true });
      let players = data.Players ?? [];

      if (filterTeam !== 'all') {
        players = players.filter(p => p.Team === filterTeam);
      }

      if (players.length === 0) {
        return interaction.editReply({
          embeds: [embeds.info('No Players', filterTeam !== 'all' ? `No players on **${filterTeam}** team.` : 'The server is empty.')],
        });
      }

      // Group by team
      const teamMap = {};
      for (const p of players) {
        const t = p.Team ?? 'Unknown';
        if (!teamMap[t]) teamMap[t] = [];
        teamMap[t].push(p);
      }

      const embed = embeds.base()
        .setTitle(`👥  Players — ${data.Name}`)
        .setDescription(`**${data.CurrentPlayers}/${data.MaxPlayers}** players online`)
        .setTimestamp();

      for (const [team, teamPlayers] of Object.entries(teamMap)) {
        const emoji = TEAM_EMOJIS[team] ?? '🎮';
        const lines = teamPlayers.map(p => {
          let line = `\`${p.Player}\``;
          if (p.Callsign) line += ` [${p.Callsign}]`;
          if (p.WantedStars > 0) line += ` ${'⭐'.repeat(Math.min(p.WantedStars, 5))}`;
          return line;
        });

        // Discord field value cap is 1024 chars
        const chunks = [];
        let chunk = '';
        for (const line of lines) {
          if ((chunk + '\n' + line).length > 1000) {
            chunks.push(chunk);
            chunk = line;
          } else {
            chunk = chunk ? chunk + '\n' + line : line;
          }
        }
        if (chunk) chunks.push(chunk);

        embed.addFields({ name: `${emoji} ${team} (${teamPlayers.length})`, value: chunks[0] ?? 'None', inline: true });
      }

      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      if (err instanceof RateLimitError) return interaction.editReply({ embeds: [embeds.warn('Rate Limited', err.message)] });
      return interaction.editReply({ embeds: [embeds.error('API Error', err.message)] });
    }
  },
};
