'use strict';

const { SlashCommandBuilder } = require('discord.js');
const db = require('../database');
const { fetchServer, RateLimitError } = require('../api');
const embeds = require('../embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('emergencycalls')
    .setDescription('View active/recent emergency calls (911 calls) in the server.')
    .addIntegerOption(o => o.setName('limit').setDescription('Entries to show (max 20)').setMinValue(1).setMaxValue(20)),

  async execute(interaction) {
    await interaction.deferReply();
    const apiKey = db.getApiKey(interaction.guildId);
    if (!apiKey) return interaction.editReply({ embeds: [embeds.warn('Not Configured', 'Run `/setup` first.')] });

    const limit = interaction.options.getInteger('limit') ?? 10;

    try {
      const data = await fetchServer(apiKey, interaction.guildId, { EmergencyCalls: true });
      const calls = (data.EmergencyCalls ?? []).slice(0, limit);

      if (!calls.length) return interaction.editReply({ embeds: [embeds.info('No Emergency Calls', 'No active emergency calls.')] });

      const embed = embeds.base(0xED4245).setTitle(`🚨  Emergency Calls — ${data.Name}`);

      for (const c of calls) {
        embed.addFields({
          name: `Call #${c.CallNumber} — ${c.Team}`,
          value: [
            `📍 **Location:** ${c.PositionDescriptor ?? 'Unknown'}`,
            `📝 **Description:** ${c.Description ?? 'N/A'}`,
            `⏰ **Started:** <t:${c.StartedAt}:R>`,
            `👥 **Units:** ${c.Players?.length ?? 0}`,
          ].join('\n'),
          inline: false,
        });
      }

      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      if (err instanceof RateLimitError) return interaction.editReply({ embeds: [embeds.warn('Rate Limited', err.message)] });
      return interaction.editReply({ embeds: [embeds.error('API Error', err.message)] });
    }
  },
};
