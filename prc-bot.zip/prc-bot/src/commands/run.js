'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../database');
const { runCommand, RateLimitError } = require('../api');
const embeds = require('../embeds');

// Common pre-built commands for quick use
const PRESETS = {
  'restart':     ':restart',
  'fogon':       ':fog on',
  'fogoff':      ':fog off',
  'rainon':      ':rain on',
  'rainoff':     ':rain off',
  'snowon':      ':snow on',
  'snowoff':     ':snow off',
  'killall':     ':killall',
  'clearweather': ':weather clear',
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('run')
    .setDescription('Run an ER:LC command in the private server.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub =>
      sub.setName('custom')
        .setDescription('Run a custom command')
        .addStringOption(o =>
          o.setName('command')
            .setDescription('The command to run (e.g. :kick PlayerName)')
            .setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('preset')
        .setDescription('Run a preset command')
        .addStringOption(o =>
          o.setName('preset')
            .setDescription('Select a preset command')
            .setRequired(true)
            .addChoices(
              { name: '🔄 Restart Server',   value: 'restart' },
              { name: '🌫️ Fog On',           value: 'fogon' },
              { name: '☀️ Fog Off',           value: 'fogoff' },
              { name: '🌧️ Rain On',           value: 'rainon' },
              { name: '☀️ Rain Off',           value: 'rainoff' },
              { name: '❄️ Snow On',           value: 'snowon' },
              { name: '☀️ Snow Off',           value: 'snowoff' },
              { name: '💀 Kill All Players',  value: 'killall' },
              { name: '☀️ Clear Weather',      value: 'clearweather' },
            ))),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const apiKey = db.getApiKey(interaction.guildId);
    if (!apiKey) return interaction.editReply({ embeds: [embeds.warn('Not Configured', 'Run `/setup` first.')] });

    const sub = interaction.options.getSubcommand();
    let command;

    if (sub === 'preset') {
      const presetKey = interaction.options.getString('preset');
      command = PRESETS[presetKey];
      if (!command) return interaction.editReply({ embeds: [embeds.error('Unknown Preset', 'That preset was not found.')] });
    } else {
      command = interaction.options.getString('command');
      if (!command.startsWith(':')) command = ':' + command;
    }

    // Log the command use
    db.logCommand(interaction.guildId, interaction.user.id, command);

    try {
      const result = await runCommand(apiKey, interaction.guildId, command);

      return interaction.editReply({
        embeds: [embeds.success('Command Sent', [
          `**Command:** \`${command}\``,
          `**Response:** ${result?.message ?? 'Executed successfully.'}`,
          `**Sent by:** ${interaction.user}`,
        ].join('\n'))],
      });
    } catch (err) {
      if (err instanceof RateLimitError) return interaction.editReply({ embeds: [embeds.warn('Rate Limited', err.message)] });
      if (err.status === 422) return interaction.editReply({ embeds: [embeds.warn('Server Empty', 'There are no players in the private server to receive this command.')] });
      return interaction.editReply({ embeds: [embeds.error('Command Failed', err.message)] });
    }
  },
};
