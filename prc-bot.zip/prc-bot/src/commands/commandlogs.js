'use strict';

// ── commandlogs ───────────────────────────────────────────────────────────────
const { SlashCommandBuilder } = require('discord.js');
const db = require('../database');
const { fetchServer, RateLimitError } = require('../api');
const embeds = require('../embeds');

// We export multiple commands from this file for brevity.
// Each is its own module.exports-compatible object.

const commandlogs = {
  data: new SlashCommandBuilder()
    .setName('commandlogs')
    .setDescription('View recent in-game command logs.')
    .addIntegerOption(o => o.setName('limit').setDescription('Entries to show (max 25)').setMinValue(1).setMaxValue(25))
    .addStringOption(o => o.setName('filter').setDescription('Filter by player name (partial match)')),

  async execute(interaction) {
    await interaction.deferReply();
    const apiKey = db.getApiKey(interaction.guildId);
    if (!apiKey) return interaction.editReply({ embeds: [embeds.warn('Not Configured', 'Run `/setup` first.')] });

    const limit  = interaction.options.getInteger('limit') ?? 15;
    const filter = interaction.options.getString('filter')?.toLowerCase();

    try {
      const data = await fetchServer(apiKey, interaction.guildId, { CommandLogs: true });
      let logs = data.CommandLogs ?? [];
      if (filter) logs = logs.filter(l => l.Player?.toLowerCase().includes(filter));
      logs = logs.slice(0, limit);

      if (!logs.length) return interaction.editReply({ embeds: [embeds.info('No Logs', 'No command logs found.')] });

      const lines = logs.map(l => `<t:${l.Timestamp}:t> — **${l.Player}**: \`${l.Command}\``);
      return interaction.editReply({
        embeds: [embeds.base(0x5865F2).setTitle(`📋  Command Logs — ${data.Name}`).setDescription(lines.join('\n').slice(0, 4000))],
      });
    } catch (err) {
      if (err instanceof RateLimitError) return interaction.editReply({ embeds: [embeds.warn('Rate Limited', err.message)] });
      return interaction.editReply({ embeds: [embeds.error('API Error', err.message)] });
    }
  },
};

module.exports = commandlogs;
