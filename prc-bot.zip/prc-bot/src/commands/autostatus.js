'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const db = require('../database');
const embeds = require('../embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('autostatus')
    .setDescription('Manage auto-updating server status embeds.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub =>
      sub.setName('add')
        .setDescription('Set up an auto-updating status embed in a channel.')
        .addChannelOption(o =>
          o.setName('channel')
            .setDescription('Channel to post the status embed in')
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(true))
        .addStringOption(o =>
          o.setName('label')
            .setDescription('Custom title label for the embed (default: "Server Status")')))
    .addSubcommand(sub =>
      sub.setName('remove')
        .setDescription('Remove the auto-status embed from a channel.')
        .addChannelOption(o =>
          o.setName('channel')
            .setDescription('Channel to remove the status from')
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('list')
        .setDescription('List all active auto-status embeds in this server.')),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const sub = interaction.options.getSubcommand();

    if (sub === 'list') {
      const statuses = db.getGuildStatuses(interaction.guildId);
      if (!statuses.length) {
        return interaction.editReply({ embeds: [embeds.info('No Auto-Status Embeds', 'None configured. Use `/autostatus add` to create one.')] });
      }
      const lines = statuses.map(s => `• <#${s.channel_id}> — "${s.label}"`);
      return interaction.editReply({
        embeds: [embeds.info(`Auto-Status Embeds (${statuses.length})`, lines.join('\n'))],
      });
    }

    const apiKey = db.getApiKey(interaction.guildId);
    if (!apiKey) return interaction.editReply({ embeds: [embeds.warn('Not Configured', 'Run `/setup` first.')] });

    const channel = interaction.options.getChannel('channel');

    if (sub === 'remove') {
      db.deactivateStatus(interaction.guildId, channel.id);
      return interaction.editReply({ embeds: [embeds.success('Removed', `Auto-status embed removed from ${channel}.`)] });
    }

    // --- ADD ---
    const label = interaction.options.getString('label') ?? 'Server Status';

    // Post a placeholder embed; the auto-refresh loop will populate it
    let msg;
    try {
      msg = await channel.send({
        embeds: [embeds.info('⏳ Loading…', 'The server status will appear shortly. This embed updates automatically.')],
      });
    } catch {
      return interaction.editReply({
        embeds: [embeds.error('Permission Error', `I couldn't send a message in ${channel}. Please check my permissions.`)],
      });
    }

    db.upsertAutoStatus({
      guildId:   interaction.guildId,
      channelId: channel.id,
      messageId: msg.id,
      label,
    });

    return interaction.editReply({
      embeds: [embeds.success('Auto-Status Created!',
        `Status embed created in ${channel}.\nIt will refresh every **${process.env.AUTO_STATUS_INTERVAL ?? 2} minutes**.`)],
    });
  },
};
