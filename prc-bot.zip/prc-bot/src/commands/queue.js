'use strict';

const { SlashCommandBuilder } = require('discord.js');
const db = require('../database');
const { fetchServer, RateLimitError } = require('../api');
const embeds = require('../embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('queue')
    .setDescription('Check the current join queue for the private server.'),

  async execute(interaction) {
    await interaction.deferReply();
    const apiKey = db.getApiKey(interaction.guildId);
    if (!apiKey) return interaction.editReply({ embeds: [embeds.warn('Not Configured', 'Run `/setup` first.')] });

    try {
      const data = await fetchServer(apiKey, interaction.guildId, { Queue: true });
      const queue = data.Queue ?? [];

      const embed = embeds.base()
        .setTitle(`🕐  Join Queue — ${data.Name}`)
        .addFields(
          { name: '👥 Players Online', value: `${data.CurrentPlayers}/${data.MaxPlayers}`, inline: true },
          { name: '🕐 In Queue',       value: `${queue.length}`,                          inline: true },
          { name: '🔑 Join Key',        value: `\`${data.JoinKey}\``,                     inline: true },
        );

      if (queue.length > 0) {
        embed.setDescription(`Queue is active — **${queue.length}** player(s) waiting to join.`);
      } else {
        embed.setDescription('No players in the queue. The server may have open slots!');
      }

      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      if (err instanceof RateLimitError) return interaction.editReply({ embeds: [embeds.warn('Rate Limited', err.message)] });
      return interaction.editReply({ embeds: [embeds.error('API Error', err.message)] });
    }
  },
};
