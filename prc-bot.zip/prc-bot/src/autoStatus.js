'use strict';

const db = require('./database');
const { fetchServer, RateLimitError, ApiError } = require('./api');
const embeds = require('./embeds');

const INTERVAL_MS = (parseInt(process.env.AUTO_STATUS_INTERVAL ?? '2', 10)) * 60_000;

let client = null;

async function refreshAll() {
  const statuses = db.getAllActiveStatuses();
  if (!statuses.length) return;

  // Group by guild to batch guild data fetching
  const byGuild = {};
  for (const s of statuses) {
    if (!byGuild[s.guild_id]) byGuild[s.guild_id] = [];
    byGuild[s.guild_id].push(s);
  }

  for (const [guildId, rows] of Object.entries(byGuild)) {
    const apiKey = db.getApiKey(guildId);
    if (!apiKey) continue;

    let data;
    try {
      data = await fetchServer(apiKey, null, { Players: true, Queue: true }); // no per-guild rl for refresh
    } catch (err) {
      if (err instanceof RateLimitError) continue;
      // On error keep old embed; log and continue
      console.warn(`[AutoStatus] Guild ${guildId} fetch failed: ${err.message}`);
      continue;
    }

    for (const row of rows) {
      try {
        const guild   = await client.guilds.fetch(guildId).catch(() => null);
        if (!guild) { db.deactivateStatus(guildId, row.channel_id); continue; }

        const channel = await guild.channels.fetch(row.channel_id).catch(() => null);
        if (!channel) { db.deactivateStatus(guildId, row.channel_id); continue; }

        const embed = embeds.serverStatus(data, row.label)
          .setFooter({ text: `PRC Bot • Auto-refreshes every ${process.env.AUTO_STATUS_INTERVAL ?? 2}m` });

        if (row.message_id) {
          const msg = await channel.messages.fetch(row.message_id).catch(() => null);
          if (msg) {
            await msg.edit({ embeds: [embed] });
            continue;
          }
        }

        // Message gone — create a new one
        const newMsg = await channel.send({ embeds: [embed] });
        db.updateStatusMessageId(row.id, newMsg.id);
      } catch (innerErr) {
        console.warn(`[AutoStatus] Failed updating channel ${row.channel_id}:`, innerErr.message);
      }
    }
  }
}

function start(discordClient) {
  client = discordClient;
  console.log(`[AutoStatus] Refresh loop started (every ${INTERVAL_MS / 60000}m)`);
  setInterval(() => refreshAll().catch(console.error), INTERVAL_MS);
  // First run shortly after boot
  setTimeout(() => refreshAll().catch(console.error), 5_000);
}

module.exports = { start };
