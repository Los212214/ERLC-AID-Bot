'use strict';

const { EmbedBuilder, Colors } = require('discord.js');

const BRAND_COLOR = 0x5865F2; // Discord blurple
const SUCCESS_COLOR = 0x57F287;
const ERROR_COLOR = 0xED4245;
const WARN_COLOR = 0xFEE75C;
const INFO_COLOR = 0x5865F2;

function timestamp() {
  return Math.floor(Date.now() / 1000);
}

function base(color = BRAND_COLOR) {
  return new EmbedBuilder()
    .setColor(color)
    .setTimestamp()
    .setFooter({ text: 'PRC Bot • ER:LC API v2' });
}

function success(title, description) {
  return base(SUCCESS_COLOR).setTitle(`✅  ${title}`).setDescription(description ?? null);
}

function error(title, description) {
  return base(ERROR_COLOR).setTitle(`❌  ${title}`).setDescription(description ?? null);
}

function warn(title, description) {
  return base(WARN_COLOR).setTitle(`⚠️  ${title}`).setDescription(description ?? null);
}

function info(title, description) {
  return base(INFO_COLOR).setTitle(`ℹ️  ${title}`).setDescription(description ?? null);
}

/**
 * Builds the full server-status embed from /v2/server data.
 */
function serverStatus(data, label = 'Server Status') {
  const embed = base(BRAND_COLOR)
    .setTitle(`🚔  ${label}`)
    .addFields(
      { name: '🏠 Server Name',     value: data.Name ?? 'Unknown',                         inline: true },
      { name: '👥 Players',          value: `${data.CurrentPlayers ?? 0} / ${data.MaxPlayers ?? 0}`, inline: true },
      { name: '🔑 Join Key',         value: `\`${data.JoinKey ?? 'N/A'}\``,                inline: true },
      { name: '✅ Acc. Verified Req', value: data.AccVerifiedReq ?? 'None',                 inline: true },
      { name: '⚖️  Team Balance',     value: data.TeamBalance ? 'Enabled' : 'Disabled',    inline: true },
    );

  if (Array.isArray(data.Players) && data.Players.length > 0) {
    const teams = {};
    for (const p of data.Players) {
      const t = p.Team ?? 'Unknown';
      if (!teams[t]) teams[t] = [];
      teams[t].push(p.Player);
    }
    const teamText = Object.entries(teams)
      .map(([t, players]) => `**${t}** (${players.length})\n${players.slice(0, 5).map(p => `• ${p}`).join('\n')}${players.length > 5 ? `\n_+${players.length - 5} more_` : ''}`)
      .join('\n\n');
    embed.addFields({ name: '🎮 Players by Team', value: teamText.slice(0, 1024) || 'None' });
  }

  if (Array.isArray(data.Queue) && data.Queue.length > 0) {
    embed.addFields({ name: '🕐 Queue', value: `${data.Queue.length} player(s) waiting`, inline: true });
  }

  embed.setTimestamp();
  return embed;
}

/**
 * Paginate a long array into an embed with a numbered list.
 */
function pagedList(title, items, formatFn, color = INFO_COLOR) {
  const lines = items.slice(0, 20).map(formatFn);
  const overflow = items.length > 20 ? `\n_…and ${items.length - 20} more_` : '';
  return base(color)
    .setTitle(title)
    .setDescription(lines.join('\n') + overflow || 'No entries found.');
}

module.exports = {
  base,
  success,
  error,
  warn,
  info,
  serverStatus,
  pagedList,
  BRAND_COLOR,
  SUCCESS_COLOR,
  ERROR_COLOR,
  WARN_COLOR,
};
