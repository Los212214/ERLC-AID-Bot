'use strict';

const fetch = require('node-fetch');

const BASE_URL = 'https://api.policeroleplay.community';

// ── In-memory cache (per guild) ───────────────────────────────────────────────
// Keyed as `${guildId}:${cacheKey}`
const cache = new Map();
const CACHE_TTL_MS = 15_000; // 15 seconds

function cacheGet(key) {
  const entry = cache.get(key);
  if (!entry) return null;
  if (Date.now() - entry.ts > CACHE_TTL_MS) {
    cache.delete(key);
    return null;
  }
  return entry.data;
}

function cacheSet(key, data) {
  cache.set(key, { data, ts: Date.now() });
}

// ── Per-guild rate limiting ───────────────────────────────────────────────────
const rateLimitBuckets = new Map(); // guildId → { count, resetAt }
const RATE_LIMIT = parseInt(process.env.RATE_LIMIT_PER_GUILD ?? '20', 10);
const RATE_WINDOW_MS = 60_000;

function checkRateLimit(guildId) {
  const now = Date.now();
  let bucket = rateLimitBuckets.get(guildId);
  if (!bucket || now > bucket.resetAt) {
    bucket = { count: 0, resetAt: now + RATE_WINDOW_MS };
    rateLimitBuckets.set(guildId, bucket);
  }
  if (bucket.count >= RATE_LIMIT) {
    const secs = Math.ceil((bucket.resetAt - now) / 1000);
    throw new RateLimitError(`Rate limit reached. Resets in ${secs}s.`);
  }
  bucket.count++;
}

class RateLimitError extends Error {
  constructor(msg) { super(msg); this.name = 'RateLimitError'; }
}

class ApiError extends Error {
  constructor(msg, status) {
    super(msg);
    this.name = 'ApiError';
    this.status = status;
  }
}

// ── Core request helper ───────────────────────────────────────────────────────

async function request(apiKey, path, { guildId, method = 'GET', body = null, useCache = true } = {}) {
  if (guildId) checkRateLimit(guildId);

  const cacheKey = guildId ? `${guildId}:${path}` : null;
  if (useCache && method === 'GET' && cacheKey) {
    const cached = cacheGet(cacheKey);
    if (cached) return cached;
  }

  const options = {
    method,
    headers: {
      'server-key': apiKey,
      'Content-Type': 'application/json',
      'User-Agent': 'PRC-Discord-Bot/2.0',
    },
  };

  if (body) options.body = JSON.stringify(body);

  const res = await fetch(`${BASE_URL}${path}`, options);

  if (res.status === 403) throw new ApiError('Invalid or unauthorized API key.', 403);
  if (res.status === 422) throw new ApiError('No players are in the private server.', 422);
  if (res.status === 500) {
    const j = await res.json().catch(() => ({}));
    throw new ApiError(j?.error ?? 'Roblox communication error.', 500);
  }
  if (!res.ok) throw new ApiError(`Unexpected response: ${res.status}`, res.status);

  const data = await res.json();

  if (useCache && method === 'GET' && cacheKey) cacheSet(cacheKey, data);

  return data;
}

// ── Public API methods ────────────────────────────────────────────────────────

/**
 * Fetch basic server info + optional fields.
 * @param {string} apiKey
 * @param {string} guildId
 * @param {object} fields - { Players, Staff, JoinLogs, Queue, KillLogs, CommandLogs, ModCalls, EmergencyCalls, Vehicles }
 */
async function fetchServer(apiKey, guildId, fields = {}) {
  const params = new URLSearchParams();
  for (const [k, v] of Object.entries(fields)) if (v) params.set(k, 'true');
  const qs = params.toString() ? `?${params}` : '';
  return request(apiKey, `/v2/server${qs}`, { guildId });
}

/**
 * Run a command in the private server.
 */
async function runCommand(apiKey, guildId, command) {
  return request(apiKey, '/v2/server/command', {
    guildId,
    method: 'POST',
    body: { command },
    useCache: false,
  });
}

// ── Cache utilities ───────────────────────────────────────────────────────────

function invalidateGuildCache(guildId) {
  for (const key of cache.keys()) {
    if (key.startsWith(`${guildId}:`)) cache.delete(key);
  }
}

module.exports = {
  fetchServer,
  runCommand,
  invalidateGuildCache,
  RateLimitError,
  ApiError,
};
