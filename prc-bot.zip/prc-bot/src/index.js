'use strict';

require('dotenv').config();

const fs   = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, Collection, Events, ActivityType } = require('discord.js');
const autoStatus = require('./autoStatus');
const embeds = require('./embeds');
const db = require('./database');

// ── Validate env ──────────────────────────────────────────────────────────────
if (!process.env.DISCORD_TOKEN) {
  console.error('❌  DISCORD_TOKEN is not set in .env');
  process.exit(1);
}

// ── Client setup ──────────────────────────────────────────────────────────────
const client = new Client({
  intents: [GatewayIntentBits.Guilds],
});

client.commands = new Collection();

// ── Load commands ─────────────────────────────────────────────────────────────
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'));

for (const file of commandFiles) {
  const command = require(path.join(commandsPath, file));
  if (!command.data || !command.execute) {
    console.warn(`⚠️  Skipping ${file} — missing data or execute export`);
    continue;
  }
  client.commands.set(command.data.name, command);
}

console.log(`✅  Loaded ${client.commands.size} command(s): ${[...client.commands.keys()].join(', ')}`);

// ── Events ────────────────────────────────────────────────────────────────────
client.once(Events.ClientReady, c => {
  console.log(`🤖  Logged in as ${c.user.tag}`);
  console.log(`📡  Serving ${c.guilds.cache.size} guild(s)`);

  c.user.setPresence({
    activities: [{ name: 'ER:LC | /status', type: ActivityType.Watching }],
    status: 'online',
  });

  autoStatus.start(c);
});

client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isChatInputCommand()) return;
  if (!interaction.guildId) {
    return interaction.reply({ content: 'This bot only works inside a server.', ephemeral: true });
  }

  const command = client.commands.get(interaction.commandName);
  if (!command) return;

  try {
    await command.execute(interaction);
  } catch (err) {
    console.error(`[Command Error] /${interaction.commandName}:`, err);
    const reply = { embeds: [embeds.error('Unexpected Error', 'Something went wrong. Please try again.')], ephemeral: true };
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply(reply).catch(() => {});
    } else {
      await interaction.reply(reply).catch(() => {});
    }
  }
});

// Clean up DB & gracefully shut down
process.on('SIGINT',  () => { db.close(); process.exit(0); });
process.on('SIGTERM', () => { db.close(); process.exit(0); });

client.login(process.env.DISCORD_TOKEN);
