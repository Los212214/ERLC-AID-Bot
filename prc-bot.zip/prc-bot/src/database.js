'use strict';

const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

// Ensure data directory exists
const DATA_DIR = path.join(__dirname, '..', 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const db = new Database(path.join(DATA_DIR, 'bot.db'));

// Enable WAL mode for better concurrent performance
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ── Schema ──────────────────────────────────────────────────────────────────

db.exec(`
  CREATE TABLE IF NOT EXISTS guild_config (
    guild_id     TEXT PRIMARY KEY,
    api_key      TEXT NOT NULL,
    setup_by     TEXT NOT NULL,
    setup_at     INTEGER NOT NULL DEFAULT (unixepoch()),
    updated_at   INTEGER NOT NULL DEFAULT (unixepoch())
  );

  CREATE TABLE IF NOT EXISTS auto_status (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id     TEXT NOT NULL,
    channel_id   TEXT NOT NULL,
    message_id   TEXT,
    label        TEXT DEFAULT 'Server Status',
    active       INTEGER NOT NULL DEFAULT 1,
    created_at   INTEGER NOT NULL DEFAULT (unixepoch()),
    UNIQUE(guild_id, channel_id)
  );

  CREATE TABLE IF NOT EXISTS command_log (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id     TEXT NOT NULL,
    user_id      TEXT NOT NULL,
    command      TEXT NOT NULL,
    ran_at       INTEGER NOT NULL DEFAULT (unixepoch())
  );
`);

// ── Guild Config ─────────────────────────────────────────────────────────────

const stmts = {
  getConfig:    db.prepare('SELECT * FROM guild_config WHERE guild_id = ?'),
  setConfig:    db.prepare(`
    INSERT INTO guild_config (guild_id, api_key, setup_by, setup_at, updated_at)
    VALUES (@guild_id, @api_key, @setup_by, unixepoch(), unixepoch())
    ON CONFLICT(guild_id) DO UPDATE SET
      api_key    = excluded.api_key,
      setup_by   = excluded.setup_by,
      updated_at = unixepoch()
  `),
  deleteConfig: db.prepare('DELETE FROM guild_config WHERE guild_id = ?'),

  // Auto-status
  getAutoStatuses:    db.prepare('SELECT * FROM auto_status WHERE active = 1'),
  getGuildStatuses:   db.prepare('SELECT * FROM auto_status WHERE guild_id = ? AND active = 1'),
  upsertAutoStatus:   db.prepare(`
    INSERT INTO auto_status (guild_id, channel_id, message_id, label)
    VALUES (@guild_id, @channel_id, @message_id, @label)
    ON CONFLICT(guild_id, channel_id) DO UPDATE SET
      message_id = excluded.message_id,
      label      = excluded.label,
      active     = 1
  `),
  updateStatusMsgId:  db.prepare('UPDATE auto_status SET message_id = ? WHERE id = ?'),
  deactivateStatus:   db.prepare('UPDATE auto_status SET active = 0 WHERE guild_id = ? AND channel_id = ?'),
  deactivateAllGuild: db.prepare('UPDATE auto_status SET active = 0 WHERE guild_id = ?'),

  // Command logs
  logCommand: db.prepare(`
    INSERT INTO command_log (guild_id, user_id, command) VALUES (?, ?, ?)
  `),
};

module.exports = {
  // ── Config ────────────────────────────────────────────────────────────────
  getConfig(guildId) {
    return stmts.getConfig.get(guildId) ?? null;
  },

  setConfig(guildId, apiKey, userId) {
    stmts.setConfig.run({ guild_id: guildId, api_key: apiKey, setup_by: userId });
  },

  deleteConfig(guildId) {
    stmts.deleteConfig.run(guildId);
  },

  getApiKey(guildId) {
    return stmts.getConfig.get(guildId)?.api_key ?? null;
  },

  // ── Auto-status ────────────────────────────────────────────────────────────
  getAllActiveStatuses() {
    return stmts.getAutoStatuses.all();
  },

  getGuildStatuses(guildId) {
    return stmts.getGuildStatuses.all(guildId);
  },

  upsertAutoStatus({ guildId, channelId, messageId = null, label = 'Server Status' }) {
    stmts.upsertAutoStatus.run({ guild_id: guildId, channel_id: channelId, message_id: messageId, label });
  },

  updateStatusMessageId(id, messageId) {
    stmts.updateStatusMsgId.run(messageId, id);
  },

  deactivateStatus(guildId, channelId) {
    stmts.deactivateStatus.run(guildId, channelId);
  },

  deactivateAllGuildStatuses(guildId) {
    stmts.deactivateAllGuild.run(guildId);
  },

  // ── Logs ──────────────────────────────────────────────────────────────────
  logCommand(guildId, userId, command) {
    stmts.logCommand.run(guildId, userId, command);
  },

  // ── Utilities ─────────────────────────────────────────────────────────────
  close() {
    db.close();
  },
};
