'use strict';

require('dotenv').config();

const { REST, Routes } = require('discord.js');
const fs   = require('fs');
const path = require('path');

const token    = process.env.DISCORD_TOKEN;
const clientId = process.env.CLIENT_ID;

if (!token || !clientId) {
  console.error('❌  DISCORD_TOKEN and CLIENT_ID must be set in .env');
  process.exit(1);
}

const commands = [];
const commandsPath = path.join(__dirname, 'src', 'commands');

for (const file of fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'))) {
  const cmd = require(path.join(commandsPath, file));
  if (cmd.data) commands.push(cmd.data.toJSON());
}

const rest = new REST().setToken(token);

(async () => {
  try {
    console.log(`📤  Deploying ${commands.length} slash command(s) globally…`);

    const data = await rest.put(
      Routes.applicationCommands(clientId),
      { body: commands },
    );

    console.log(`✅  Successfully deployed ${data.length} command(s).`);
    console.log('    Commands:', commands.map(c => `/${c.name}`).join(', '));
    console.log('\n⚠️  Global commands can take up to 1 hour to propagate to all servers.');
  } catch (err) {
    console.error('❌  Deployment failed:', err);
  }
})();
