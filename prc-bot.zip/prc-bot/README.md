# 🚔 PRC ER:LC Discord Bot v2

A production-ready Discord bot for **Police Roleplay Community (ER:LC)** private servers — built for 300+ servers with per-guild API key management, caching, rate limiting, and live auto-status embeds.

---

## ✨ Features

| Command | Description |
|---------|-------------|
| `/setup` | Link your PRC API key to this Discord server (Admin only) |
| `/status` | Full server overview (players, join key, team balance) |
| `/players` | Player list with team breakdown, callsigns & wanted stars |
| `/staff` | Online admins, mods & helpers |
| `/killlogs` | Recent kill log feed |
| `/commandlogs` | In-game command log (filter by player) |
| `/joinlogs` | Player join/leave events |
| `/modcalls` | Moderator call log |
| `/emergencycalls` | Active 911/emergency calls with location |
| `/queue` | Join queue & server slot availability |
| `/vehicles` | All spawned vehicles (name, plate, color) |
| `/run custom` | Run any ER:LC command remotely |
| `/run preset` | One-click presets (fog, rain, snow, restart, etc.) |
| `/autostatus add` | Create a live auto-updating status embed in a channel |
| `/autostatus remove` | Remove an auto-status embed |
| `/autostatus list` | List all active auto-status embeds |

---

## 🚀 Setup

### 1. Prerequisites
- **Node.js 18+** — [nodejs.org](https://nodejs.org)
- A **Discord bot** created at [discord.com/developers](https://discord.com/developers/applications)
  - Enable **Slash Commands** scope
  - Enable **bot** scope with **Send Messages**, **Embed Links**, **Read Message History**

### 2. Clone & Install

```bash
git clone <your-repo>
cd prc-bot
npm install
```

### 3. Configure Environment

```bash
cp .env.example .env
```

Edit `.env`:

```env
DISCORD_TOKEN=your_bot_token
CLIENT_ID=your_application_id
AUTO_STATUS_INTERVAL=2        # minutes between auto-status refreshes
RATE_LIMIT_PER_GUILD=20       # max API requests per guild per minute
```

### 4. Deploy Slash Commands

```bash
npm run deploy
```

> ⚠️ Global commands can take up to 1 hour to appear. For instant testing, use [guild commands](https://discord.com/developers/docs/interactions/application-commands#create-guild-application-command).

### 5. Start the Bot

```bash
npm start
# or for development (auto-restarts)
npm run dev
```

---

## ⚙️ Per-Server Configuration

Once the bot is in a server:

1. Run `/setup api_key:<your-key>` (requires Administrator)
2. Your PRC API key is found in-game: **Settings → ER:LC API → API Key**
3. The key is validated against the live PRC API before saving

---

## 🔄 Auto-Status Embeds

Auto-status embeds automatically refresh every N minutes (configurable via `AUTO_STATUS_INTERVAL`):

```
/autostatus add channel:#server-status label:🚔 Server Live Status
```

The bot will:
- Post a status embed in the chosen channel
- Edit that same message every refresh cycle (no spam)
- Handle deleted messages by re-posting automatically
- Deactivate if the channel is deleted

---

## 🏗️ Architecture

```
prc-bot/
├── src/
│   ├── index.js          # Bot entry point, event handling
│   ├── database.js       # SQLite (better-sqlite3) — guild configs & auto-status
│   ├── api.js            # PRC API v2 wrapper (caching + rate limiting)
│   ├── embeds.js         # Shared embed builder utility
│   ├── autoStatus.js     # Background refresh loop
│   └── commands/
│       ├── setup.js
│       ├── status.js
│       ├── players.js
│       ├── staff.js
│       ├── killlogs.js
│       ├── commandlogs.js
│       ├── joinlogs.js
│       ├── modcalls.js
│       ├── emergencycalls.js
│       ├── queue.js
│       ├── vehicles.js
│       ├── run.js
│       └── autostatus.js
├── deploy-commands.js    # One-time global slash command registration
├── data/                 # SQLite DB lives here (auto-created)
├── .env.example
└── package.json
```

### Designed for Scale (300+ servers)

| Feature | Implementation |
|---------|----------------|
| **Per-guild API keys** | SQLite — one row per guild, zero shared state |
| **API caching** | In-memory 15s TTL cache keyed by `guildId:endpoint` |
| **Per-guild rate limiting** | Token bucket — 20 req/min per guild (configurable) |
| **Auto-status efficiency** | Edits existing messages — 1 API call per guild per cycle |
| **WAL mode SQLite** | Concurrent reads without blocking writes |
| **Graceful shutdown** | `SIGINT`/`SIGTERM` handlers close the DB cleanly |

---

## 🔐 Security Notes

- API keys are stored in a local SQLite database — ensure the `data/` folder has appropriate filesystem permissions
- The `/run` and `/setup` commands require **Manage Guild** / **Administrator** permissions
- Consider encrypting stored API keys using `crypto` if hosting on a shared machine

---

## 📦 Hosting Recommendations

| Platform | Notes |
|----------|-------|
| **VPS (DigitalOcean, Hetzner, Vultr)** | Best for persistent SQLite + 24/7 uptime |
| **Railway / Render** | Easy deploys; use a persistent disk for `data/` |
| **PM2** | `pm2 start npm --name prc-bot -- start` for process management |

---

## 📄 License

MIT — feel free to fork and adapt.
